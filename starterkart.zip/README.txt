StarterKart - Static demo site
This ZIP contains a static demo portfolio for StarterKart (Shopify Theme Customisation).
- Brand colors: #E0B1CB and #231942
- WhatsApp contact link: https://wa.me/9818082449
- Admin demo password: starter123 (demo only)

To make this production-ready:
- Add a real backend (Node/Express, Django, etc.)
- Implement secure authentication and storage for admin
- Replace placeholder images with real screenshots
- Connect contact form to backend endpoint (e.g., /api/contact)
